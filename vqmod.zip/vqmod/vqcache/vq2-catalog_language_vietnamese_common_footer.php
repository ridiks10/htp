<?php
// Text
$_['text_information']  = 'Sumy';

				$_['text_news'] = 'Our News';
			
$_['text_service']      = 'Hỗ trợ hội viên';
$_['text_extra']        = 'Chính sách & quy định';
$_['text_contact']      = 'Liên hệ';
$_['text_return']       = 'Trả hàng';
$_['text_sitemap']      = 'Sơ đồ trang';
$_['text_manufacturer'] = 'Thương hiệu - hãng';
$_['text_voucher']      = 'Phiếu quà tặng';
$_['text_affiliate']    = 'Đại lý quảng cáo';
$_['text_special']      = 'Khuyến mãi';
$_['text_account']      = 'Tài khoản';
$_['text_order']        = 'Lịch sử đơn hàng dịch vụ';
$_['text_wishlist']     = 'Danh sách yêu thích';
$_['text_newsletter']   = 'Thư thông báo';
$_['text_powered']      = 'Bản quyền của %s &copy; %s';

				$_['text_simple_blog']   = 'Simple Blog';
			
